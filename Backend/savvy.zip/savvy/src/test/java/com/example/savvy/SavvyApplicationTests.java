package com.example.savvy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SavvyApplicationTests {

	@Test
	void contextLoads() {
	}

}
