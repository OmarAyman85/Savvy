package com.example.savvy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SavvyApplication {

	public static void main(String[] args) {
		SpringApplication.run(SavvyApplication.class, args);
	}

}
